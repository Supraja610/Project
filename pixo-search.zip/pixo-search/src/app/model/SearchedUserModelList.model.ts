import { SearchedUserModel } from './SearchedUserModel.model';

export class SearchedUserModelList
{
    userList:Array<SearchedUserModel>
}