package com.pixogram.userservice.model;

import java.util.List;

import com.pixogram.userservice.entity.User;

import lombok.Getter;
import lombok.Setter;

//@Getter
//@Setter
public class UserData {
	
	public List<User> getData() {
		return data;
	}

	public void setData(List<User> data) {
		this.data = data;
	}

	List<User> data;
}
