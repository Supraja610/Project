import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-followers-following',
  templateUrl: './followers-following.component.html',
  styleUrls: ['./followers-following.component.css']
})
export class FollowersFollowingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
