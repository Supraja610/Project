package com.cts.training.userservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.repository.UserRepository;

@Component
public class UserServiceImp implements IUserService {
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		return this.userRepository.findAll();
	
	}

	@Override
	public User findUserById(Integer id) {
		Optional<User> record =  this.userRepository.findById(id);
				User User = new User();
		if(record.isPresent())
			User = record.get();
		return User;
		
	}

	@Override
	public boolean addUser(User User) {
		this.userRepository.save(User);
		return true;
	}

	@Override
	public boolean updateUser(User User) {
		this.userRepository.save(User);
		return true;
	}

	@Override
	public boolean deleteUser(Integer id) {
		this.userRepository.deleteById(id);
		return true;
	}
	


}
