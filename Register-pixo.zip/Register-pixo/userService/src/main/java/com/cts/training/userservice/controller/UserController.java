package com.cts.training.userservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.userservice.entity.Users;
import com.cts.training.userservice.exception.UserErrorResponse;
import com.cts.training.userservice.exception.UserNotFoundException;
import com.cts.training.userservice.repository.UserRepository;
import com.cts.training.userservice.service.IUserService;

@RestController
public class UserController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private IUserService userService;

	
	
	
	
	@GetMapping("/users") // GET HTTP VERB
	public ResponseEntity<List<Users>> exposeAll() {
		
		List<Users> users = this.userService.findAllUsers();
		ResponseEntity<List<Users>> response = 
								new ResponseEntity<List<Users>>(users, HttpStatus.OK);
		
		
		return response;
	}	
	
	// REST method that will recieve a movie Id and return details of that movie
	@GetMapping("/users/{userId}") // GET HTTP VERB
	public ResponseEntity<Users> getById(@PathVariable Integer userId) {
		
		Users users = this.userService.findUserById(userId);
		ResponseEntity<Users> response = 
				new ResponseEntity<Users>(users, HttpStatus.OK);

		return response;
	}
	
	
	
	@PostMapping("/users") // POST HTTP VERB
	public ResponseEntity<Users> save(@RequestBody Users users) {
		this.userService.addUser(users);
		ResponseEntity<Users> response = 
				new ResponseEntity<Users>(users, HttpStatus.OK);

		return response;
	}
	
	
	
	@PutMapping("/users/{userId}")
	
		public ResponseEntity<Users> saveUpdate(@PathVariable Integer userId,@RequestBody Users users) {
		
		Users u = new Users ();

		if(!this.userService.updateUser(u))
			throw new RuntimeException("could not update");
			
		ResponseEntity<Users> response = 
				new ResponseEntity<Users>(u, HttpStatus.OK);

		return response;
	}
	
	
	
	
	
	@DeleteMapping("/users/{userId}")
	public ResponseEntity<Users> delete(@PathVariable Integer userId) {
		
		Users users = this.userService.findUserById(userId);
		this.userService.deleteUser(userId);
		
		ResponseEntity<Users> response = 
				new ResponseEntity<Users>(users, HttpStatus.OK);

		return response;
	}
	
	
	
	
	
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<UserErrorResponse> UserNotFoundHandler(UserNotFoundException ex) {
		// create error object
		UserErrorResponse error = new UserErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<UserErrorResponse> response =
										new ResponseEntity<UserErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<UserErrorResponse> UserOperationErrorHAndler(Exception ex) {
		// create error object
		UserErrorResponse error = new UserErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<UserErrorResponse> response =
										new ResponseEntity<UserErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	
	
	
	/************ REST endpoints ************/
	// /api/User [GET]
	// /api/User/id [GET]
	// /api/User [POST]
	// /api/User [PUT]
	// /api/User/id [DELETE]
	
	
	
	
}
	












