package com.cts.training.userservice.service;

import java.util.List;

import com.cts.training.userservice.entity.Users;






public interface IUserService {

	List<Users> findAllUsers();
	Users findUserById(Integer id);
	boolean addUser(Users Users);
	boolean updateUser(Users Users);
	boolean deleteUser(Integer id);
}
