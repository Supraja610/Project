package com.cts.training.Blockservice.service;

import java.util.List;

import org.springframework.cglib.core.Block;

public class BlockServiceImp implements IBlockService {

	@Override
	public List<Block> findAllBlocks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Block findBlockById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addBlock(Block Block) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateBlock(Block Block) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteBlock(Integer id) {
		// TODO Auto-generated method stub
		return false;
	}

}
