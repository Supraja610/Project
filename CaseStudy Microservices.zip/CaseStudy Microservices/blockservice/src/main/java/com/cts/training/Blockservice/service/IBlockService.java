package com.cts.training.Blockservice.service;

import java.util.List;

import org.springframework.cglib.core.Block;



public interface IBlockService {

	List<Block> findAllBlocks();
	Block findBlockById(Integer id);
	boolean addBlock(Block Block);
	boolean updateBlock(Block Block);
	boolean deleteBlock(Integer id);

	
}
