package com.cts.training.actionservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.actionservice.entity.Action;
import com.cts.training.actionservice.service.IActionService;


@RestController
public class ActionController {

	// dependency
	@Autowired
	private IActionService actionservice;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/action/{actionId}")
	public ResponseEntity<Action> getById(@PathVariable Integer actionId){
		
		Action action = this.actionservice.findActionById(actionId);
	
		ResponseEntity<Action> response = new ResponseEntity<Action>(action, HttpStatus.OK);
		return response;
	}
	
	@PostMapping("/actions")
		public ResponseEntity<Action> save(@RequestBody Action action) {
			this.actionservice.addAction(action);
			ResponseEntity<Action> response = 
					new ResponseEntity<Action>(action, HttpStatus.OK);

			return response;
	}
	
	@PutMapping("/actions")
	public ResponseEntity<Action> saveUpdate(@RequestBody Action Action) {
		this.actionservice.updateAction(Action);
			
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(Action, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/actions/{actionId}")
	public ResponseEntity<Action> delete(@PathVariable Integer ActionId) {
		
		Action Action = this.actionservice.findActionById(ActionId);
		this.actionservice.deleteAction(ActionId);
		
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(Action, HttpStatus.OK);

		return response;
	}
	
	
}












