package com.cts.training.actionservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.training.actionservice.entity.Action;
import com.cts.training.actionservice.repository.ActionRepository;

@Component
public class ActionServiceImp implements IActionService {
	
	@Autowired
	private ActionRepository actionRepository;

	@Override
	public List<Action> findAllActions() {
		// TODO Auto-generated method stub
		return this.actionRepository.findAll();
	
	}

	@Override
	public Action findActionById(Integer id) {
		Optional<Action> record =  this.actionRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Action Action = new Action();
		if(record.isPresent())
			Action = record.get();
		return Action;
		
	}

	@Override
	public boolean addAction(Action Action) {
		this.actionRepository.save(Action);
		return true;
	}

	@Override
	public boolean updateAction(Action Action) {
		this.actionRepository.save(Action);
		return true;
	}

	@Override
	public boolean deleteAction(Integer id) {
		this.actionRepository.deleteById(id);
		return true;
	}
	

}
