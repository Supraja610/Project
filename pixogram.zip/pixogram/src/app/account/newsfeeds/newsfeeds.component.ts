import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { NewsFeed } from 'src/app/model/NewsFeed.model';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-newsfeeds',
  templateUrl: './newsfeeds.component.html',
  styleUrls: ['./newsfeeds.component.css']
})
export class NewsfeedsComponent implements OnInit {

  feeds:NewsFeed[];
  constructor(public auth : AuthenticationService,public userserviceService:UserserviceService,public userAuthService:UserAuthService) { }
  message():void{
    
    alert("Logged out!!!");
    this.auth.logout();
  }
  
  ngOnInit() {
    this.userserviceService.getAllFeed(this.userAuthService.getUserId()).subscribe(data=>
      {
        this.feeds=data;
      })
   
  }

}
