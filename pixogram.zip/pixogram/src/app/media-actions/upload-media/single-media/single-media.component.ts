import { Component, OnInit } from '@angular/core';
import{FormGroup, FormControl, FormBuilder, Validators} from'@angular/forms';
import { Router } from '@angular/router';
import { Media } from 'src/app/model/media-model';
import { UploadMediaService } from 'src/app/services/upload/upload-media.service';
import { UserAuthService } from 'src/app/services/user-auth.service';
@Component({
  selector: 'app-single-media',
  templateUrl: './single-media.component.html',
  styleUrls: ['./single-media.component.css']
})
export class SingleMediaComponent implements OnInit {
  ngOnInit() {
    this.userId=this.auth.getUserId();
  }
  title1:string;
  userId:string;
  description: string;
  tag1: string;
  url:string;
  myFormGroup:FormGroup;
  selectedFiles:FileList;
  currentUploadFile:File;
  date:Date;
  type:string;
  public imagePath;
  imgURL: any;
  constructor(formBuilder: FormBuilder,public router:Router,public uploadService : UploadMediaService, public auth: UserAuthService) {
    console.log("in form bilder of single media");
    this.myFormGroup=formBuilder.group({
      "title1":new FormControl(""),
      "description":new FormControl(""),
      "tags1":new FormControl("")
    });

  }
  onImageLoad(event){
    this.selectedFiles=event.target.files;
    this.currentUploadFile=this.selectedFiles.item(0);
    this.preview(this.selectedFiles);
  }
  preview(files){
    if(files.length === 0)
    return;

    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null){
      return;
    }
    
  var reader = new FileReader();
  this.imagePath = files;
  reader.readAsDataURL(files[0]);
  reader.onload = (_event) => {
    this.imgURL = reader.result;
  }
}

  mediaDetails(){

    this.title1= this.myFormGroup.controls['title1'].value;
    this.description=this.myFormGroup.controls['description'].value;
    this.tag1=this.myFormGroup.controls['tags1'].value;
    this.type=this.currentUploadFile.type;
    this.date=new Date();
    let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
    if (this.currentUploadFile.type == 'image/png') {
      this.url = `${this.userId}${dateString}.png`;
    }
    if (this.currentUploadFile.type == 'image/jpeg' || this.currentUploadFile.type == 'image/jpg') {
      this.url = `${this.userId}${dateString}.jpeg`;
    }
    this.uploadService.pushFileToMediaStorage(this.currentUploadFile,this.url,this.title1,this.description,this.tag1,this.type,this.userId).subscribe(data=>{
  
      this.router.navigate(["/mymedia"])
    });
}
}
