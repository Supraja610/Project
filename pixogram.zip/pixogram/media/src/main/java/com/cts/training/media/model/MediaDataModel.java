package com.cts.training.media.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString


public class MediaDataModel implements Serializable {
	
	private Integer userId;
	private String url;
	private String title;
	private String description;
	private String tags;
	private String type;
	

}
