package com.pixogram.userservice.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
public class UserErrorResponse {
	@Override
	public String toString() {
		return "UserErrorResponse [message=" + message + ", errorCode=" + errorCode + ", timeStamp=" + timeStamp + "]";
	}
	public UserErrorResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserErrorResponse(String message, Integer errorCode, Long timeStamp) {
		super();
		this.message = message;
		this.errorCode = errorCode;
		this.timeStamp = timeStamp;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}
	public Long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}
	private String message;
	private Integer errorCode;
	private Long timeStamp;
	
}
