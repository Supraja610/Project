package com.pixogram.userservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Getter
//@Setter
//@AllArgsConstructor
//@NoArgsConstructor
public class ResponseData {
	@Override
	public String toString() {
		return "ResponseData [message=" + message + ", timeStamp=" + timeStamp + ", userId=" + userId + "]";
	}
	public ResponseData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResponseData(String message, Long timeStamp, Integer userId) {
		super();
		this.message = message;
		this.timeStamp = timeStamp;
		this.userId = userId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	private String message;
	private Long timeStamp;
	private Integer userId;

}
