package com.cts.training.mediaservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.repository.MediaRepository;

public class MediaServiceImp implements IMediaService {
	
	@Autowired
	private MediaRepository mediaRepository;

	@Override
	public List<Media> findAllMedias() {
		// TODO Auto-generated method stub
		return this.mediaRepository.findAll();
	
	}

	@Override
	public Media findMediaById(Integer id) {
		Optional<Media> record =  this.mediaRepository.findById(id);
				Media Media = new Media();
		if(record.isPresent())
			Media = record.get();
		return Media;
		
	}

	@Override
	public boolean addMedia(Media Media) {
		this.mediaRepository.save(Media);
		return true;
	}

	@Override
	public boolean updateMedia(Media Media) {
		this.mediaRepository.save(Media);
		return true;
	}

	@Override
	public boolean deleteMedia(Integer id) {
		this.mediaRepository.deleteById(id);
		return true;
	}
	


}
