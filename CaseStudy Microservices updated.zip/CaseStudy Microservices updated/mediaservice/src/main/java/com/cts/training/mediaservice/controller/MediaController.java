package com.cts.training.mediaservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.service.IMediaService;
import com.cts.training.mediaservice.entity.Media;

import com.cts.training.mediaservice.repository.MediaRepository;

@RestController
public class MediaController {

	@Autowired
	private IMediaService mediaservice;
	
	@GetMapping("/media/{mediaId}")
	public ResponseEntity<Media> getById(@PathVariable Integer mediaId){
		
		Media media = this.mediaservice.findMediaById(mediaId);
	
		ResponseEntity<Media> response = new ResponseEntity<Media>(media, HttpStatus.OK);
		return response;
	}
	
	@PostMapping("/medias")
		public ResponseEntity<Media> save(@RequestBody Media media) {
			this.mediaservice.addMedia(media);
			ResponseEntity<Media> response = 
					new ResponseEntity<Media>(media, HttpStatus.OK);

			return response;
	}
	
	@PutMapping("/medias/{mediaId}")
	public ResponseEntity<Media> saveUpdate(@RequestBody Media Media) {
		this.mediaservice.updateMedia(Media);
			
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(Media, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/medias/{mediaId}")
	public ResponseEntity<Media> delete(@PathVariable Integer MediaId) {
		
		Media Media = this.mediaservice.findMediaById(MediaId);
		this.mediaservice.deleteMedia(MediaId);
		
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(Media, HttpStatus.OK);

		return response;
	}
	

}












