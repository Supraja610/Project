package com.cts.training.Newsfeedservice.Service;

import java.util.List;

import com.cts.training.Newsfeedservice.entity.Newsfeed;



public interface INewsFeedService {
	
	List<Newsfeed> findAllNewsFeeds();
	Newsfeed findNewsFeedById(Integer id);
	boolean addNewsFeed(Newsfeed NewsFeed);
	boolean updateNewsFeed(Newsfeed NewsFeed);
	boolean deleteNewsFeed(Integer id);


}
