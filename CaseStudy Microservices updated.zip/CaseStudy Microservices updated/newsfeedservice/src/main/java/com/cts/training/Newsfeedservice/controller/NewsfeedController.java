package com.cts.training.Newsfeedservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.Newsfeedservice.Service.INewsFeedService;
import com.cts.training.Newsfeedservice.entity.Newsfeed;
import com.cts.training.Newsfeedservice.repository.NewsfeedRepository;


@RestController
public class NewsfeedController {

	@Autowired
	private INewsFeedService newsfeedservice;
	
	@GetMapping("/newsfeed/{newsfeedId}")
	public ResponseEntity<Newsfeed> getById(@PathVariable Integer newsfeedId){
		
		Newsfeed newsfeed = this.newsfeedservice.findNewsFeedById(newsfeedId);
	
		ResponseEntity<Newsfeed> response = new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);
		return response;
	}
	
	@PostMapping("/newsfeeds")
		public ResponseEntity<Newsfeed> save(@RequestBody Newsfeed newsfeed) {
			this.newsfeedservice.addNewsFeed(newsfeed);
			ResponseEntity<Newsfeed> response = 
					new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

			return response;
	}
	
	@PutMapping("/newsfeeds/{newsfeedId}")
	public ResponseEntity<Newsfeed> saveUpdate(@RequestBody Newsfeed Newsfeed) {
		this.newsfeedservice.updateNewsFeed(Newsfeed);
			
		ResponseEntity<Newsfeed> response = 
				new ResponseEntity<Newsfeed>(Newsfeed, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/newsfeeds/{newsfeedId}")
	public ResponseEntity<Newsfeed> delete(@PathVariable Integer NewsfeedId) {
		
		Newsfeed Newsfeed = this.newsfeedservice.findNewsFeedById(NewsfeedId);
		this.newsfeedservice.deleteNewsFeed(NewsfeedId);
		
		ResponseEntity<Newsfeed> response = 
				new ResponseEntity<Newsfeed>(Newsfeed, HttpStatus.OK);

		return response;
	}
	

}












