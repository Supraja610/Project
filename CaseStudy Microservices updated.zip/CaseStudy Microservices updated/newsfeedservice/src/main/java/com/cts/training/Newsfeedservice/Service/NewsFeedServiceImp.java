package com.cts.training.Newsfeedservice.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.training.Newsfeedservice.entity.Newsfeed;
import com.cts.training.Newsfeedservice.repository.NewsfeedRepository;

public class NewsFeedServiceImp implements INewsFeedService {
	
	@Autowired
	private NewsfeedRepository newsfeedRepository;

	@Override
	public List<Newsfeed> findAllNewsFeeds() {
		// TODO Auto-generated method stub
		return this.newsfeedRepository.findAll();
	
	}

	@Override
	public Newsfeed findNewsFeedById(Integer id) {
		Optional<Newsfeed> record =  this.newsfeedRepository.findById(id);
				Newsfeed NewsFeed = new Newsfeed();
		if(record.isPresent())
			NewsFeed = record.get();
		return NewsFeed;
		
	}

	@Override
	public boolean addNewsFeed(Newsfeed NewsFeed) {
		this.newsfeedRepository.save(NewsFeed);
		return true;
	}

	@Override
	public boolean updateNewsFeed(Newsfeed NewsFeed) {
		this.newsfeedRepository.save(NewsFeed);
		return true;
	}

	@Override
	public boolean deleteNewsFeed(Integer id) {
		this.newsfeedRepository.deleteById(id);
		return true;
	}
	


}
