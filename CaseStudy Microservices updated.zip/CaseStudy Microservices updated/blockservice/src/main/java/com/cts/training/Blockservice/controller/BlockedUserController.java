package com.cts.training.Blockservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.Blockservice.entity.BlockedUser;

import com.cts.training.Blockservice.repository.BlockedUserRepository;
import com.cts.training.Blockservice.service.IBlockService;




@RestController
public class BlockedUserController {

	// dependency
	@Autowired
	private IBlockService blockedservice;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/blockedusers/{blockeduserId}")
public ResponseEntity<BlockedUser> getById(@PathVariable Integer blockeduserId){
		
		BlockedUser block = this.blockedservice.findBlockedUserById(blockeduserId);
	
		ResponseEntity<BlockedUser> response = new ResponseEntity<BlockedUser>(block, HttpStatus.OK);
		return response;
	}
	
	@PostMapping("/blockedusers")
	public ResponseEntity<BlockedUser> save(@RequestBody BlockedUser blockeduser) {
		this.blockedservice.addBlockedUser(blockeduser);
		ResponseEntity<BlockedUser> response = 
				new ResponseEntity<BlockedUser>(blockeduser, HttpStatus.OK);

		return response;
}
	
	@PutMapping("/blockedusers")
	public ResponseEntity<BlockedUser> saveUpdate(@RequestBody BlockedUser blockeduser) {
		this.blockedservice.updateBlockeduser(blockeduser);
			
		ResponseEntity<BlockedUser> response = 
				new ResponseEntity<BlockedUser>(blockeduser, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/blockedusers/{blockedusersId}")
	public ResponseEntity<BlockedUser> delete(@PathVariable Integer blockeduserId) {
		
		BlockedUser BlockedUser = this.blockedservice.findBlockedUserById(blockeduserId);
		this.blockedservice.deleteBlockedUser(blockeduserId);
		
		ResponseEntity<BlockedUser> response = 
				new ResponseEntity<BlockedUser>(BlockedUser, HttpStatus.OK);

		return response;
	}
	
}












