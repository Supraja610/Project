package com.cts.training.Blockservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.training.Blockservice.entity.BlockedUser;
import com.cts.training.Blockservice.repository.BlockedUserRepository;



public class BlockedServiceImp implements IBlockService {
	
	@Autowired
	private BlockedUserRepository blockeduserRepository;


	@Override
	public List<BlockedUser> findAllBlocks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BlockedUser findBlockedUserById(Integer id) {
		Optional<BlockedUser> record =  this.blockeduserRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		BlockedUser BlockedUser = new BlockedUser();
		if(record.isPresent())
			BlockedUser = record.get();
		return BlockedUser;
		
	}

	@Override
	public boolean addBlockedUser(BlockedUser Block) {
		this.blockeduserRepository.save(Block);
		return true;
	}

	@Override
	public boolean updateBlockeduser(BlockedUser Block) {
		this.blockeduserRepository.save(Block);
		return true;
	}

	@Override
	public boolean deleteBlockedUser(Integer id) {
		this.blockeduserRepository.deleteById(id);
		return true;
	}
	}

