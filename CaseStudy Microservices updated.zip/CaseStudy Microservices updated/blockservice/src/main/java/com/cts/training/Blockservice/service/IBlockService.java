package com.cts.training.Blockservice.service;

import java.util.List;

import org.springframework.cglib.core.Block;

import com.cts.training.Blockservice.entity.BlockedUser;



public interface IBlockService {

	List<BlockedUser> findAllBlocks();
	BlockedUser findBlockedUserById(Integer id);
	boolean addBlockedUser(BlockedUser Block);
	boolean updateBlockeduser(BlockedUser Block);
	boolean deleteBlockedUser(Integer id);
	
		

	
}
