package com.cts.training.commentservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cts.training.commentservice.entity.Comment;
import com.cts.training.commentservice.repository.CommentRepository;
import com.cts.training.commentservice.service.ICommentService;


@RestController
public class CommentController {

	
	@Autowired
	private ICommentService commentservice;
	
	@GetMapping("/comment/{commentId}")
	public ResponseEntity<Comment> getById(@PathVariable Integer commentId){
		
		Comment comment = this.commentservice.findCommentById(commentId);
	
		ResponseEntity<Comment> response = new ResponseEntity<Comment>(comment, HttpStatus.OK);
		return response;
	}
	
	@PostMapping("/comments")
		public ResponseEntity<Comment> save(@RequestBody Comment comment) {
			this.commentservice.addComment(comment);
			ResponseEntity<Comment> response = 
					new ResponseEntity<Comment>(comment, HttpStatus.OK);

			return response;
	}
	
	@PutMapping("/comments/{commentId}")
	public ResponseEntity<Comment> saveUpdate(@RequestBody Comment Comment) {
		this.commentservice.updateComment(Comment);
			
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(Comment, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/comments/{commentId}")
	public ResponseEntity<Comment> delete(@PathVariable Integer CommentId) {
		
		Comment Comment = this.commentservice.findCommentById(CommentId);
		this.commentservice.deleteComment(CommentId);
		
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(Comment, HttpStatus.OK);

		return response;
	}
	

}












