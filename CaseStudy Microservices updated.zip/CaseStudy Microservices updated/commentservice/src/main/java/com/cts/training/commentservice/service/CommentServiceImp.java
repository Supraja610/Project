package com.cts.training.commentservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.training.commentservice.entity.Comment;
import com.cts.training.commentservice.repository.CommentRepository;

public class CommentServiceImp implements ICommentService {
	
	@Autowired
	private CommentRepository commentRepository;

	@Override
	public List<Comment> findAllActions() {
		return this.commentRepository.findAll();
	}

	@Override
	public Comment findCommentById(Integer id) {
		Optional<Comment> record =  this.commentRepository.findById(id);
		Comment Comment = new Comment();
        if(record.isPresent())
	     Comment = record.get();
       return Comment;
	  }

	@Override
	public boolean addComment(Comment Comment) {
		this.commentRepository.save(Comment);
		return true;
	}

	@Override
	public boolean updateComment(Comment Comment) {
		this.commentRepository.save(Comment);
		return true;
	}

	@Override
	public boolean deleteComment(Integer id) {
		this.commentRepository.deleteById(id);
		return true;
	}
	
	
	

}
