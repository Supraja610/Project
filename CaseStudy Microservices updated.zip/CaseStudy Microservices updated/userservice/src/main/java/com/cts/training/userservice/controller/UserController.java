package com.cts.training.userservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.userservice.service.IUserService;
import com.cts.training.userservice.entity.User;
import com.cts.training.userservice.repository.UserRepository;

@RestController
public class UserController {

	@Autowired
	private IUserService userservice;
	
	@GetMapping("/user/{userId}")
public ResponseEntity<User> getById(@PathVariable Integer userId){
		
		User user = this.userservice.findUserById(userId);
	
		ResponseEntity<User> response = new ResponseEntity<User>(user, HttpStatus.OK);
		return response;	
	}
	
	@PostMapping("/users")
		public ResponseEntity<User> save(@RequestBody User user) {
			this.userservice.addUser(user);
			ResponseEntity<User> response = 
					new ResponseEntity<User>(user, HttpStatus.OK);

			return response;
	}
	
	@PutMapping("/users/{userId}")
	public ResponseEntity<User> saveUpdate(@RequestBody User User) {
		this.userservice.updateUser(User);
			
		ResponseEntity<User> response = 
				new ResponseEntity<User>(User, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/users/{userId}")
	public ResponseEntity<User> delete(@PathVariable Integer UserId) {
		
		User User = this.userservice.findUserById(UserId);
		this.userservice.deleteUser(UserId);
		
		ResponseEntity<User> response = 
				new ResponseEntity<User>(User, HttpStatus.OK);

		return response;
	}
	

}












