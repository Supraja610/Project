package com.cts.training.followservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.training.followservice.entity.Follow;
import com.cts.training.followservice.repository.FollowRepository;
import com.cts.training.followservice.entity.Follow;

public class FollowServiceImp implements IFollowService {
	
	@Autowired
	private FollowRepository followRepository;


	@Override
	public List<Follow> findAllFollows() {
		return this.followRepository.findAll();
	}

	@Override
	public Follow findFollowById(Integer id) {
		Optional<Follow> record =  this.followRepository.findById(id);
		Follow Follow = new Follow();
if(record.isPresent())
	Follow = record.get();
return Follow;
	}

	@Override
	public boolean addFollow(Follow Follow) {
		this.followRepository.save(Follow);
		return true;
	}

	@Override
	public boolean updateFollow(Follow Follow) {
		this.followRepository.save(Follow);
		return true;
	}

	@Override
	public boolean deleteFollow(Integer id) {
		this.followRepository.deleteById(id);
		return true;
	}
	
	

}
