package com.cts.training.followservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.followservice.entity.Follow;
import com.cts.training.followservice.service.IFollowService;
import com.cts.training.followservice.entity.Follow;
import com.cts.training.followservice.repository.FollowRepository;


@RestController
public class FollowController {

	
	@Autowired
	private IFollowService followservice;
	
	@GetMapping("/follow/{followId}")
	public ResponseEntity<Follow> getById(@PathVariable Integer followId){
		
		Follow follow = this.followservice.findFollowById(followId);
	
		ResponseEntity<Follow> response = new ResponseEntity<Follow>(follow, HttpStatus.OK);
		return response;
	}
	
	@PostMapping("/follows")
		public ResponseEntity<Follow> save(@RequestBody Follow follow) {
			this.followservice.addFollow(follow);
			ResponseEntity<Follow> response = 
					new ResponseEntity<Follow>(follow, HttpStatus.OK);

			return response;
	}
	
	@PutMapping("/follows/{followId}")
	public ResponseEntity<Follow> saveUpdate(@RequestBody Follow Follow) {
		this.followservice.updateFollow(Follow);
			
		ResponseEntity<Follow> response = 
				new ResponseEntity<Follow>(Follow, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/follows/{followId}")
	public ResponseEntity<Follow> delete(@PathVariable Integer FollowId) {
		
		Follow Follow = this.followservice.findFollowById(FollowId);
		this.followservice.deleteFollow(FollowId);
		
		ResponseEntity<Follow> response = 
				new ResponseEntity<Follow>(Follow, HttpStatus.OK);

		return response;
	}
	

}












